/*
ASSIGNMENT 4 SUBMISSION
Name : Karan Kumar Sethi
Roll No. : 22CS30034
File : user2.c
*/ 
#include "ksocket.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

#define BUFFER_SIZE 512

int main(int argc, char *argv[]) {
    if (argc != 6) {
        fprintf(stderr, "Usage: %s <local_ip> <local_port> <remote_ip> <remote_port> <output_filename>\n", argv[0]);
        exit(1);
    }

    // Create KTP socket
    int sockfd = k_socket(AF_INET, SOCK_KTP, 0);
    if (sockfd < 0) {
        perror("k_socket failed");
        exit(1);
    }

    // Bind socket
    if (k_bind(sockfd, argv[1], atoi(argv[2]), argv[3], atoi(argv[4])) < 0) {
        perror("k_bind failed");
        exit(1);
    }

    // Open output file
    FILE *fp = fopen(argv[5], "wb");
    if (!fp) {
        perror("Failed to open output file");
        k_close(sockfd);
        exit(1);
    }

    // Receive file
    char buffer[BUFFER_SIZE];
    size_t total_bytes = 0;
    
    printf("Waiting for file transfer...\n");
    
    while (1) {
        ssize_t received = k_recvfrom(sockfd, buffer, BUFFER_SIZE, 0);
        if (received < 0) {
            if (errno == EAGAIN) {
                // No message available, check if transfer is complete
                if (total_bytes > 0) {
                    // Wait for a while to see if more data comes
                    usleep(100000);  // 100ms
                    continue;
                }
            } else {
                perror("k_recvfrom failed");
                break;
            }
        } else {
            size_t written = fwrite(buffer, 1, received, fp);
            if (written != received) {
                perror("Failed to write to file");
                break;
            }
            total_bytes += written;
            printf("\rReceived %zu bytes...", total_bytes);
            fflush(stdout);
        }
    }

    printf("\nFile transfer complete. Total bytes received: %zu\n", total_bytes);

    fclose(fp);
    k_close(sockfd);
    return 0;
}