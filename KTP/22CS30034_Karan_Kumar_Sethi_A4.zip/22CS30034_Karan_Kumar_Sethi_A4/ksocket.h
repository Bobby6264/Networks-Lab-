/*
ASSIGNMENT 4 SUBMISSION
Name : Karan Kumar Sethi
Roll No. : 22CS30034
File : ksocket.h
*/

#ifndef KSOCKET_H
#define KSOCKET_H

#include <stdint.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/select.h>
#include <fcntl.h>
#include <errno.h>
#include <netdb.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <pthread.h>

#define T 5                   // Timeout of 5 seconds
#define MAX_MSG_SIZE 512      // Maximum message size (bytes)
#define MAX_KTP_SOCK 10       // Maximum number of sockets
#define WINDOW_SIZE 10        // Window size

// Socket type for KTP
#define SOCK_KTP 1234

// KTP Message Types
#define KTP_DATA 1
#define KTP_ACK 2

// KTP Header Structure
struct ktp_header {
    uint8_t seq_num;       // 8-bit sequence number
    uint8_t type;          // Message type (DATA or ACK)
    uint16_t rwnd;         // Receiver window size
    uint32_t checksum;     // Checksum for data integrity
};

// Window Structure
struct window {
    uint8_t base;        // Base sequence number
    uint8_t next_seq_num;// Next sequence number
    uint8_t size;        // Current window size
    uint8_t max_size;    // Maximum window size
    struct timespec last_sent[WINDOW_SIZE];  // Timestamps of last transmissions
};

struct ktp_statistics {
    uint64_t messages_sent;
    uint64_t messages_received;
    uint64_t messages_dropped;
    uint64_t retransmissions;
    uint64_t duplicate_messages;
    uint64_t out_of_order_messages;
    uint64_t acks_sent;
    uint64_t acks_received;
    uint64_t timeouts;
    struct timespec start_time;
};

// Socket Information Structure
struct ktp_socket_info {
    int is_active;                          // Socket in use?
    pid_t process_id;                       // Owner process ID
    int udp_socket;                         // Underlying UDP socket
    struct sockaddr_in local_addr;          // Local address
    struct sockaddr_in remote_addr;         // Remote address
    char send_buffer[WINDOW_SIZE][MAX_MSG_SIZE];  // Send buffer
    char recv_buffer[WINDOW_SIZE][MAX_MSG_SIZE];  // Receive buffer
    struct window swnd;                     // Sending window
    struct ktp_statistics stats;            // Statistics
    struct window rwnd;                     // Receiving window
    pthread_mutex_t socket_mutex;           // Per-socket mutex
};

// Shared Memory Structure (for managing multiple sockets)
struct shared_memory {
    struct ktp_socket_info sockets[MAX_KTP_SOCK];
    pthread_mutex_t sm_mutex;  // Mutex for shared memory access
};

// Function declarations
int k_socket(int domain, int type, int protocol);
int k_bind(int sockfd, const char* src_ip, int src_port, const char* dest_ip, int dest_port);
ssize_t k_sendto(int sockfd, const void *buf, size_t len, int flags);
ssize_t k_recvfrom(int sockfd, void *buf, size_t len, int flags);
int k_close(int sockfd);
int dropMessage(float p);

#endif
