/*
ASSIGNMENT 4 SUBMISSION
Name : Karan Kumar Sethi
Roll No. : 22CS30034
File : initksocket.c
*/ 

#include "ksocket.h"
#include <pthread.h>
#include <signal.h>

// Thread functions
void* receiver_thread(void* arg) {
    char buffer[sizeof(struct ktp_header) + MAX_MESSAGE_SIZE];
    
    while (1) {
        fd_set readfds;
        struct timeval tv;
        int max_fd = -1;
        
        FD_ZERO(&readfds);
        
        // Add all active UDP sockets to fd_set
        pthread_mutex_lock(&sm->sm_mutex);
        for (int i = 0; i < MAX_KTP_SOCKETS; i++) {
            if (sm->sockets[i].is_active) {
                FD_SET(sm->sockets[i].udp_socket, &readfds);
                if (sm->sockets[i].udp_socket > max_fd) {
                    max_fd = sm->sockets[i].udp_socket;
                }
            }
        }
        pthread_mutex_unlock(&sm->sm_mutex);
        
        if (max_fd == -1) {
            usleep(100000);  // 100ms
            continue;
        }
        
        tv.tv_sec = 1;
        tv.tv_usec = 0;
        
        int ready = select(max_fd + 1, &readfds, NULL, NULL, &tv);
        if (ready <= 0) continue;
        
        // Process ready sockets
        pthread_mutex_lock(&sm->sm_mutex);
        for (int i = 0; i < MAX_KTP_SOCKETS; i++) {
            if (!sm->sockets[i].is_active) continue;
            
            if (FD_ISSET(sm->sockets[i].udp_socket, &readfds)) {
                struct sockaddr_in sender_addr;
                socklen_t addr_len = sizeof(sender_addr);
                
                ssize_t recv_len = recvfrom(sm->sockets[i].udp_socket, 
                                          buffer, sizeof(buffer), 0,
                                          (struct sockaddr*)&sender_addr, 
                                          &addr_len);
                
                if (recv_len > 0) {
                    struct ktp_header* header = (struct ktp_header*)buffer;
                    
                    if (header->type == KTP_DATA) {
                        process_data_message(&sm->sockets[i], buffer, recv_len);
                    } else if (header->type == KTP_ACK) {
                        process_ack_message(&sm->sockets[i], header);
                    }
                }
            }
        }
        pthread_mutex_unlock(&sm->sm_mutex);
    }
    
    return NULL;
}
void* sender_thread(void* arg) {
    struct timespec current_time;
    
    while (1) {
        // Sleep for T/2 seconds
        struct timespec sleep_time = {T/2, 0};
        nanosleep(&sleep_time, NULL);
        
        clock_gettime(CLOCK_MONOTONIC, &current_time);
        
        pthread_mutex_lock(&sm->sm_mutex);
        for (int i = 0; i < MAX_KTP_SOCKETS; i++) {
            if (!sm->sockets[i].is_active) continue;
            
            struct ktp_socket_info* sock = &sm->sockets[i];
            
            // Check for timeouts
            for (uint8_t seq = sock->swnd.base; 
                 seq != sock->swnd.next_seq_num; 
                 seq = (seq + 1) % 256) {
                
                int buf_idx = seq % WINDOW_SIZE;
                struct timespec* last_sent = &sock->swnd.last_sent[buf_idx];
                
                double elapsed = (current_time.tv_sec - last_sent->tv_sec) +
                               (current_time.tv_nsec - last_sent->tv_nsec) * 1e-9;
                
                if (elapsed >= T) {
                    // Retransmit message
                    struct ktp_header header;
                    header.seq_num = seq;
                    header.type = KTP_DATA;
                    header.rwnd = sock->rwnd.size;
                    
                    char message[sizeof(struct ktp_header) + MAX_MESSAGE_SIZE];
                    memcpy(message, &header, sizeof(header));
                    memcpy(message + sizeof(header), 
                           sock->send_buffer[buf_idx], 
                           MAX_MESSAGE_SIZE);
                    
                    sendto(sock->udp_socket, message, 
                           sizeof(header) + MAX_MESSAGE_SIZE, 0,
                           (struct sockaddr*)&sock->remote_addr, 
                           sizeof(sock->remote_addr));
                    
                    clock_gettime(CLOCK_MONOTONIC, &sock->swnd.last_sent[buf_idx]);
                }
            }
        }
        pthread_mutex_unlock(&sm->sm_mutex);
    }
    
    return NULL;
}
// Garbage collector process
void garbage_collector() {
    while (1) {
        sleep(1);
        
        pthread_mutex_lock(&sm->sm_mutex);
        for (int i = 0; i < MAX_KTP_SOCKETS; i++) {
            if (sm->sockets[i].is_active) {
                if (kill(sm->sockets[i].process_id, 0) < 0) {
                    // Process no longer exists
                    sm->sockets[i].is_active = 0;
                    close(sm->sockets[i].udp_socket);
                }
            }
        }
        pthread_mutex_unlock(&sm->sm_mutex);
    }
}

void process_data_message(struct ktp_socket_info* sock, const char* buffer, size_t len) {
    struct ktp_header* header = (struct ktp_header*)buffer;
    
    // Check if message should be dropped
    if (dropMessage(drop_probability)) {
        return;
    }
    
    // Check if sequence number is within receive window
    uint8_t expected_seq = sock->rwnd.next_seq_num;
    if (header->seq_num != expected_seq) {
        // Out of order or duplicate - store if within window
        if ((header->seq_num > expected_seq && 
             header->seq_num < expected_seq + sock->rwnd.size) ||
            (expected_seq + sock->rwnd.size > 255 && 
             header->seq_num < (expected_seq + sock->rwnd.size) % 256)) {
            
            int buf_idx = header->seq_num % WINDOW_SIZE;
            memcpy(sock->recv_buffer[buf_idx], 
                   buffer + sizeof(struct ktp_header), 
                   len - sizeof(struct ktp_header));
        }
        return;
    }
    
    // Store message
    int buf_idx = header->seq_num % WINDOW_SIZE;
    memcpy(sock->recv_buffer[buf_idx], 
           buffer + sizeof(struct ktp_header), 
           len - sizeof(struct ktp_header));
    
    // Update window
    sock->rwnd.next_seq_num = (sock->rwnd.next_seq_num + 1) % 256;
    sock->rwnd.size = WINDOW_SIZE - 
                      ((sock->rwnd.next_seq_num - sock->rwnd.base + 256) % 256);
    
    // Send ACK
    struct ktp_header ack_header;
    ack_header.seq_num = header->seq_num;
    ack_header.type = KTP_ACK;
    ack_header.rwnd = sock->rwnd.size;
    
    sendto(sock->udp_socket, &ack_header, sizeof(ack_header), 0,
           (struct sockaddr*)&sock->remote_addr, sizeof(sock->remote_addr));
}

void process_ack_message(struct ktp_socket_info* sock, const struct ktp_header* header) {
    // Check if message should be dropped
    if (dropMessage(drop_probability)) {
        return;
    }
    
    // Update send window
    if (header->seq_num >= sock->swnd.base && 
        header->seq_num < sock->swnd.next_seq_num) {
        sock->swnd.base = (header->seq_num + 1) % 256;
        sock->swnd.size = header->rwnd;
    }
}


int main() {
    // Initialize shared memory
    if (init_shared_memory() < 0) {
        perror("Failed to initialize shared memory");
        return 1;
    }
    
    // Create threads
    pthread_t r_thread, s_thread;
    pthread_create(&r_thread, NULL, receiver_thread, NULL);
    pthread_create(&s_thread, NULL, sender_thread, NULL);
    
    // Fork garbage collector
    pid_t gc_pid = fork();
    if (gc_pid == 0) {
        garbage_collector();
        exit(0);
    }
    
    // Wait for threads (they never exit in this implementation)
    pthread_join(r_thread, NULL);
    pthread_join(s_thread, NULL);
    
    return 0;
}

