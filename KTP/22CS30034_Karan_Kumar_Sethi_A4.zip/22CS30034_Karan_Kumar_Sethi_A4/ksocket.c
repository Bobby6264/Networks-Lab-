/*
ASSIGNMENT 4 SUBMISSION
Name : Karan Kumar Sethi
Roll No. : 22CS30034
File : ksocket.c
*/

// Ensure _POSIX_C_SOURCE is defined before any system headers!
#define _POSIX_C_SOURCE 199309L

#include "ksocket.h"
#include <sys/shm.h>
#include <pthread.h>
#include <time.h>
#include <errno.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/socket.h>

// Global shared memory pointer and shared memory ID
static struct shared_memory* sm = NULL;
static int shm_id = -1;

// Initialize shared memory for managing sockets
static int init_shared_memory() {
    if (sm != NULL) return 0;  // Already initialized

    // Create shared memory segment
    shm_id = shmget(IPC_PRIVATE, sizeof(struct shared_memory), IPC_CREAT | 0666);
    if (shm_id < 0) return -1;

    // Attach to shared memory
    sm = (struct shared_memory*)shmat(shm_id, NULL, 0);
    if (sm == (void*)-1) return -1;

    // Initialize mutex attribute for process sharing
    pthread_mutexattr_t attr;
    pthread_mutexattr_init(&attr);
    pthread_mutexattr_setpshared(&attr, PTHREAD_PROCESS_SHARED);
    pthread_mutex_init(&sm->sm_mutex, &attr);

    // Initialize all socket entries and their mutexes
    for (int i = 0; i < MAX_KTP_SOCK; i++) {
        sm->sockets[i].is_active = 0;
        pthread_mutex_init(&sm->sockets[i].socket_mutex, &attr);
    }

    pthread_mutexattr_destroy(&attr);
    return 0;
}

int k_socket(int domain, int type, int protocol) {
    if (type != SOCK_KTP) {
        errno = EINVAL;
        return -1;
    }

    if (init_shared_memory() < 0) {
        errno = ENOMEM;
        return -1;
    }

    pthread_mutex_lock(&sm->sm_mutex);

    // Find a free socket slot
    int slot = -1;
    for (int i = 0; i < MAX_KTP_SOCK; i++) {
        if (!sm->sockets[i].is_active) {
            slot = i;
            break;
        }
    }

    if (slot < 0) {
        pthread_mutex_unlock(&sm->sm_mutex);
        errno = ENOBUFS;  // No free socket available
        return -1;
    }

    // Create the underlying UDP socket
    int udp_sock = socket(domain, SOCK_DGRAM, protocol);
    if (udp_sock < 0) {
        pthread_mutex_unlock(&sm->sm_mutex);
        return -1;
    }

    // Initialize the socket info in the selected slot
    sm->sockets[slot].is_active = 1;
    sm->sockets[slot].process_id = getpid();
    sm->sockets[slot].udp_socket = udp_sock;

    // Initialize sending window
    sm->sockets[slot].swnd.base = 1;
    sm->sockets[slot].swnd.next_seq_num = 1;
    sm->sockets[slot].swnd.size = WINDOW_SIZE;
    sm->sockets[slot].swnd.max_size = WINDOW_SIZE;

    // Initialize receiving window
    sm->sockets[slot].rwnd.size = WINDOW_SIZE;
    sm->sockets[slot].rwnd.max_size = WINDOW_SIZE;

    pthread_mutex_unlock(&sm->sm_mutex);
    return slot;  // Return the slot index as the socket descriptor
}

int k_bind(int sockfd, const char* src_ip, int src_port, const char* dest_ip, int dest_port) {
    if (sockfd < 0 || sockfd >= MAX_KTP_SOCK) {
        errno = EINVAL;
        return -1;
    }

    pthread_mutex_lock(&sm->sm_mutex);
    if (!sm->sockets[sockfd].is_active) {
        pthread_mutex_unlock(&sm->sm_mutex);
        errno = EBADF;
        return -1;
    }

    // Setup local address information
    struct sockaddr_in local_addr;
    memset(&local_addr, 0, sizeof(local_addr));
    local_addr.sin_family = AF_INET;
    local_addr.sin_port = htons(src_port);
    inet_pton(AF_INET, src_ip, &local_addr.sin_addr);

    // Setup remote address information
    struct sockaddr_in remote_addr;
    memset(&remote_addr, 0, sizeof(remote_addr));
    remote_addr.sin_family = AF_INET;
    remote_addr.sin_port = htons(dest_port);
    inet_pton(AF_INET, dest_ip, &remote_addr.sin_addr);

    // Bind the UDP socket to the local address
    if (bind(sm->sockets[sockfd].udp_socket, (struct sockaddr*)&local_addr, sizeof(local_addr)) < 0) {
        pthread_mutex_unlock(&sm->sm_mutex);
        return -1;
    }

    // Store the addresses in the socket structure
    sm->sockets[sockfd].local_addr = local_addr;
    sm->sockets[sockfd].remote_addr = remote_addr;

    pthread_mutex_unlock(&sm->sm_mutex);
    return 0;
}

ssize_t k_sendto(int sockfd, const void *buf, size_t len, int flags) {
    if (sockfd < 0 || sockfd >= MAX_KTP_SOCK || !buf || len > MAX_MSG_SIZE) {
        errno = EINVAL;
        return -1;
    }

    // Get the socket information and lock its mutex
    struct ktp_socket_info* sock = &sm->sockets[sockfd];
    pthread_mutex_lock(&sock->socket_mutex);

    if (!sock->is_active) {
        pthread_mutex_unlock(&sock->socket_mutex);
        errno = EBADF;
        return -1;
    }

    // Ensure that the socket is bound (remote port must be non-zero)
    if (sock->remote_addr.sin_port == 0) {
        pthread_mutex_unlock(&sock->socket_mutex);
        errno = ENOTCONN;
        return -1;
    }

    // Check if the sending window is full
    if ((sock->swnd.next_seq_num - sock->swnd.base + WINDOW_SIZE) % WINDOW_SIZE == 0) {
        pthread_mutex_unlock(&sock->socket_mutex);
        errno = ENOBUFS;
        return -1;
    }

    // Prepare the message (header + data)
    char message[sizeof(struct ktp_header) + MAX_MSG_SIZE];
    struct ktp_header* header = (struct ktp_header*)message;
    header->seq_num = sock->swnd.next_seq_num;
    header->type = KTP_DATA;
    header->rwnd = sock->rwnd.size;
    // (Checksum calculation could be added here if desired)

    // Copy the user data into the message
    memcpy(message + sizeof(struct ktp_header), buf, len);

    // Save the message in the send buffer (for potential retransmission)
    int buf_idx = sock->swnd.next_seq_num % WINDOW_SIZE;
    memcpy(sock->send_buffer[buf_idx], buf, len);

    // Record the send time using CLOCK_MONOTONIC
    clock_gettime(CLOCK_MONOTONIC, &sock->swnd.last_sent[buf_idx]);

    // Update the next sequence number (wrap around at 256)
    sock->swnd.next_seq_num = (sock->swnd.next_seq_num + 1) % 256;

    // Send the message using the underlying UDP socket
    ssize_t sent = sendto(sock->udp_socket, message,
                          sizeof(struct ktp_header) + len, flags,
                          (struct sockaddr*)&sock->remote_addr, sizeof(sock->remote_addr));

    pthread_mutex_unlock(&sock->socket_mutex);
    return (sent < 0) ? -1 : len;
}

ssize_t k_recvfrom(int sockfd, void *buf, size_t len, int flags) {
    if (sockfd < 0 || sockfd >= MAX_KTP_SOCK || !buf || len < MAX_MSG_SIZE) {
        errno = EINVAL;
        return -1;
    }

    struct ktp_socket_info* sock = &sm->sockets[sockfd];
    pthread_mutex_lock(&sock->socket_mutex);

    if (!sock->is_active) {
        pthread_mutex_unlock(&sock->socket_mutex);
        errno = EBADF;
        return -1;
    }

    // Check if a message is available in the receive buffer
    if (sock->rwnd.base == sock->rwnd.next_seq_num) {
        pthread_mutex_unlock(&sock->socket_mutex);
        errno = ENOMSG;
        return -1;
    }

    // Copy the first available message from the receive buffer
    int buf_idx = sock->rwnd.base % WINDOW_SIZE;
    memcpy(buf, sock->recv_buffer[buf_idx], MAX_MSG_SIZE);

    // Update the receiving window
    sock->rwnd.base = (sock->rwnd.base + 1) % 256;
    sock->rwnd.size = WINDOW_SIZE - ((sock->rwnd.next_seq_num - sock->rwnd.base + 256) % 256);

    pthread_mutex_unlock(&sock->socket_mutex);
    return MAX_MSG_SIZE;
}

int k_close(int sockfd) {
    if (sockfd < 0 || sockfd >= MAX_KTP_SOCK) {
        errno = EINVAL;
        return -1;
    }

    pthread_mutex_lock(&sm->sm_mutex);
    if (!sm->sockets[sockfd].is_active) {
        pthread_mutex_unlock(&sm->sm_mutex);
        errno = EBADF;
        return -1;
    }

    // Close the underlying UDP socket
    close(sm->sockets[sockfd].udp_socket);

    // Clear the socket information
    sm->sockets[sockfd].is_active = 0;
    memset(&sm->sockets[sockfd].local_addr, 0, sizeof(struct sockaddr_in));
    memset(&sm->sockets[sockfd].remote_addr, 0, sizeof(struct sockaddr_in));

    pthread_mutex_unlock(&sm->sm_mutex);
    return 0;
}

static float drop_probability = 0.1;  // Default 10% drop rate

int dropMessage(float p) {
    drop_probability = p;
    float random = (float)rand() / RAND_MAX;
    return random < p;
}
