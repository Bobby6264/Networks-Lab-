/*
ASSIGNMENT 4 SUBMISSION
Name : Karan Kumar Sethi
Roll No. : 22CS30034
File : user1.c
*/ 
#include "ksocket.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

#define BUFFER_SIZE 512

int main(int argc, char *argv[]) {
    if (argc != 6) {
        fprintf(stderr, "Usage: %s <local_ip> <local_port> <remote_ip> <remote_port> <filename>\n", argv[0]);
        exit(1);
    }

    // Create KTP socket
    int sockfd = k_socket(AF_INET, SOCK_KTP, 0);
    if (sockfd < 0) {
        perror("k_socket failed");
        exit(1);
    }

    // Bind socket
    if (k_bind(sockfd, argv[1], atoi(argv[2]), argv[3], atoi(argv[4])) < 0) {
        perror("k_bind failed");
        exit(1);
    }

    // Open file
    FILE *fp = fopen(argv[5], "rb");
    if (!fp) {
        perror("Failed to open file");
        k_close(sockfd);
        exit(1);
    }

    // Send file
    char buffer[BUFFER_SIZE];
    size_t bytes_read;
    size_t total_bytes = 0;
    
    printf("Starting file transfer...\n");
    
    while ((bytes_read = fread(buffer, 1, BUFFER_SIZE, fp)) > 0) {
        ssize_t sent = k_sendto(sockfd, buffer, bytes_read, 0);
        if (sent < 0) {
            if (errno == EAGAIN) {
                // Buffer full, wait and retry
                usleep(100000);  // 100ms
                continue;
            }
            perror("k_sendto failed");
            break;
        }
        total_bytes += sent;
        printf("\rSent %zu bytes...", total_bytes);
        fflush(stdout);
    }

    printf("\nFile transfer complete. Total bytes sent: %zu\n", total_bytes);

    fclose(fp);
    k_close(sockfd);
    return 0;
}
